var header = document.getElementById("menuLinks");
var links = header.getElementsByClassName("menu-link");

for (var i = 0; i < links.length; i++) {
  links[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active-menu");
    current[0].className = current[0].className.replace(" active-menu", "");
    this.className += " active-menu";
    });
}