function abrirNivel(idName) {
  var header = document.getElementById("navLinks");
  var links = header.getElementsByClassName("link");
  var linkActive = document.getElementById(idName);

  if (linkActive.classList) {
    linkActive.classList.add('active');
    for (var i = 0; i < links.length; i++) {
      if (links[i].id != idName) {
        if(links[i].className.includes("active")) {
          links[i].classList.remove('active');
        }
      }
    }
  } else {
    linkActive.className += " active";
  }

  if (idName == 'sobreArea') {
    openLevel('lvl_op8wtg', []);

  } else if (idName == 'acompProj') {
    params = {'A_FILTRO' : null};
    openLevel('lvl_op8wtc', params);

  } else if (idName == 'novaSol') {
    openLevel('lvl_op8wte', []);
  }
}