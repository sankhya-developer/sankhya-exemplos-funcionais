function tipoDemanda(tipo){
  var params = {'A_FILTRO' : tipo};
  refreshDetails('cht_pyvutr', params); //grafico de barras - Solicitações abertas por STATUS
  refreshDetails('cht_pyvutt', params); //grafico de colunas - Solicitações abertas por TIPO
}