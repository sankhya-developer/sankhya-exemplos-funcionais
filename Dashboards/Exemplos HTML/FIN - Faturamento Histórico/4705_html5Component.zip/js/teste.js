function montaFaturamentoAcumulado(P_ANOVEND, P_ANOFATUR){
    var query = SQL_FATURAMENTO_ACUMULADO;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    if(P_ANOVEND != ""){
        query += " AND EXTRACT(YEAR FROM DTVENDA) = ? ";
        arr.push({value: P_ANOVEND, type:"I"});
    }

    if(P_ANOVEND != ""){
        query += " AND EXTRACT(YEAR FROM DTVENDA) = ? ";
        arr.push({value: P_ANOVEND, type:"I"});
    }

    query += " GROUP BY DAS.DTVENDA, FAT.DTFATUR "
    
    console.log('Query executada:' + query);

    executeQuery(query,arr,function(value){
        var dadosTabela = JSON.parse(value);

        console.log(dadosTabela);

        /*if(dadosTabela.length > 0){
            var colunasTabela = Object.keys(dadosTabela[0]);
            var nroColunas = colunasTabela.length;
            var table = document.getElementById("tabelaParceiros");

            montaHeaderTable(table, colunasTabela);

            for (var k in dadosTabela) {
                var row = table.insertRow(-1);
                
                for (var j in dadosTabela[k]) {
                    row.insertCell(-1).innerHTML = dadosTabela[k][j];
                }
            
                row.insertCell(-1).innerHTML = "<button type='button' onclick='mostraDetalhesContato("+dadosTabela[k]["CODPARC"]+")'>Contatos</button>";

            }
            document.getElementById("tabelaParceiros").style.visibility = "visible";
            
        }*/
    },function(value){
        alert(value);
    });
}