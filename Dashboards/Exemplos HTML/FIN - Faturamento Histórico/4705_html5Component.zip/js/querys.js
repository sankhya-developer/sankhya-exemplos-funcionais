/*Este arquivo contem as consultas bases para fornecer dados ao indicador

Observações:
    1 - Os parametros devem ser acrescentado a query conforme necessidade do indicador
    2 - As clausulas que vem depois do WHERE também devem ser acrescentadas depois (GROUP BY, ORDER BY, HAVING)
*/ 
var SQL_VENDAS_CANCELADAS =
    "SELECT DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'MM'), "+
    "                               'T', TO_CHAR(A.DTREF, 'Q'), "+
    "                               'A', '1') AS REF_VENDA, "+
    "       DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'Mon/YYYY'), "+ 
    "                               'T', TO_CHAR(A.DTREF, 'Q') ||' Tri'||TO_CHAR(A.DTREF, '/YYYY'), "+  
    "                               'A', TO_CHAR(A.DTREF, 'YYYY')) AS PER_VENDA, "+
    "       DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'YYYYMM'), "+  
    "                               'T', TO_CHAR(A.DTREF, 'YYYYQ'), "+
    "                               'A', TO_CHAR(A.DTREF, 'YYYY')) AS ORDEM_VENDA, "+ 
    "       SUM(A.VLR_NOTA + A.LUMISTA_LOC + A.DEVOLUCOES) AS VALOR "+ 
    "  FROM ( "+
    "        SELECT TRUNC(DAS.DTREF,'MM') AS DTREF, "+ 
    "               NVL(SUM(CASE WHEN DAS.CODPARC NOT IN (SELECT -1 FROM DUAL) AND DAS.CODTIPOPER = 116 "+
    "                            THEN VALOR "+
    "                            ELSE 0 "+
    "                       END),0) AS CANCELADO, "+ 
    "               NVL(SUM(CASE WHEN DAS.CODTIPOPER <> 113 "+ 
    "                             AND DAS.CODNAT NOT IN (110609, 110118 , 110107) "+ 
    "                             AND DAS.DEVOLVIDA = 'N' "+
    "                            THEN DAS.VALOR "+
    "                       END),0) AS VLR_NOTA, "+ 
    "               NVL(SUM(CASE WHEN DAS.DEVOLVIDA = 'S' THEN DAS.VALOR ELSE 0 END),0) AS DEVOLUCOES, "+ 
    "               NVL(SUM(CASE WHEN (DAS.CODTIPOPER = 113 OR DAS.CODNAT IN (110609, 110118 , 110107)) "+
"                                 AND DAS.DEVOLVIDA = 'N' "+
    "                            THEN DAS.VALOR "+
    "                       END),0) AS LUMISTA_LOC "+ 
    "         FROM VGFVENDAS_JOIN_G DAS "+
    "              INNER JOIN TSICUS CUS ON CUS.CODCENCUS = DAS.CODCENCUS "+ 
    "              INNER JOIN AD_UNIDADESBPS BPS ON DAS.NROUNICOBP = BPS.NROUNICO "+ 
    "        WHERE 1=1 "+
    "          AND CUS.AD_CATEGORIA IN ('M', 'U') "+
    "          AND TRUNC(DAS.CODNAT, -2) IN (110100, 110300, 110600, 110700, 110800, 110900) "+ 
    "          AND DAS.CODTIPOPER <> 113 AND DAS.CODNAT NOT IN (110609, 110118 , 110107) "+
    "          AND DAS.DEVOLVIDA = 'S' AND TRUNC(DAS.DTREF,'MM') <> '01/01/2020' "+
    "        GROUP BY TRUNC(DAS.DTREF,'MM') "+
    "       ) A "+
    " WHERE 1 = 1"
;

var GROUP_VENDAS_CANCELADAS =
    "GROUP BY DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'MM'), "+
    "                                 'T', TO_CHAR(A.DTREF, 'Q'), "+
    "                                 'A', '1'), "+
    "         DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'Mon/YYYY'), "+ 
    "                                 'T', TO_CHAR(A.DTREF, 'Q') ||' Tri'||TO_CHAR(A.DTREF, '/YYYY'), "+
    "                                 'A', TO_CHAR(A.DTREF, 'YYYY')), "+
    "         DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'YYYYMM'), "+ 
    "                                 'T', TO_CHAR(A.DTREF, 'YYYYQ'), "+
    "                                 'A', TO_CHAR(A.DTREF, 'YYYY')) "
;

var SQL_VENDAS_TOTAIS =
    "SELECT DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'MM'), "+
    "                               'T', TO_CHAR(A.DTREF, 'Q'),  "+
    "                               'A', '1') AS REF_VENDA, "+
    "       DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'Mon/YYYY'), "+ 
    "                               'T', TO_CHAR(A.DTREF, 'Q') ||' Tri'||TO_CHAR(A.DTREF, '/YYYY'), "+ 
    "                               'A', TO_CHAR(A.DTREF, 'YYYY')) AS PER_VENDA, "+
    "       DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'YYYYMM'),  "+
    "                               'T', TO_CHAR(A.DTREF, 'YYYYQ'),  "+
    "                               'A', TO_CHAR(A.DTREF, 'YYYY')) AS ORDEM_VENDA, "+
    "       SUM(A.VLR_NOTA + A.LUMISTA_LOC + A.DEVOLUCOES) AS VALOR "+
    "  FROM ( "+
    "        SELECT TRUNC(DAS.DTREF,'MM') AS DTREF,  "+
    "               NVL(SUM(CASE WHEN DAS.CODPARC NOT IN (SELECT -1 FROM DUAL) AND DAS.CODTIPOPER = 116 "+
    "                            THEN VALOR "+
    "                            ELSE 0 "+
    "                       END),0) AS CANCELADO, "+
    "               NVL(SUM(CASE WHEN DAS.CODTIPOPER <> 113 "+
    "                             AND DAS.CODNAT NOT IN (110609, 110118 , 110107) "+
    "                             AND DAS.DEVOLVIDA = 'N' "+
    "                            THEN DAS.VALOR "+
    "                       END),0) AS VLR_NOTA, "+
    "               NVL(SUM(CASE WHEN DAS.DEVOLVIDA = 'S' THEN DAS.VALOR ELSE 0 END),0) AS DEVOLUCOES, "+
    "               NVL(SUM(CASE WHEN (DAS.CODTIPOPER = 113 OR DAS.CODNAT IN (110609, 110118 , 110107)) "+
    "                             AND DAS.DEVOLVIDA = 'N' "+
    "                            THEN DAS.VALOR "+
    "                       END),0) AS LUMISTA_LOC  "+
    "          FROM VGFVENDAS_JOIN_G DAS "+
    "               INNER JOIN TSICUS CUS ON CUS.CODCENCUS = DAS.CODCENCUS "+
    "               INNER JOIN AD_UNIDADESBPS BPS ON DAS.NROUNICOBP = BPS.NROUNICO "+
    "         WHERE 1=1 "+
    "           AND CUS.AD_CATEGORIA IN ('M', 'U') "+
    "           AND TRUNC(DAS.CODNAT, -2) IN (110100, 110300, 110600, 110700, 110800, 110900)  "+
    "           AND DAS.CODTIPOPER <> 113 AND DAS.CODNAT NOT IN (110609, 110118 , 110107) "+
    "           AND (TO_CHAR(DAS.DTREF,'MM') = '01' AND DEVOLVIDA = 'N' OR TO_CHAR(DAS.DTREF,'MM') <> '01') "+
    "           AND NVL(DAS.MOTIVO, 'RS') = 'RS' "+
    "         GROUP BY TRUNC(DAS.DTREF,'MM') "+
    "     ) A " +
    " WHERE 1=1 ";
    
    ;
;
var GROUP_VENDAS_TOTAIS = 
    " GROUP BY DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'MM'), "+ 
    "                                  'T', TO_CHAR(A.DTREF, 'Q'),  "+
    "                                  'A', '1'),  "+
    "          DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'Mon/YYYY'), "+ 
    "                                  'T', TO_CHAR(A.DTREF, 'Q') ||' Tri'||TO_CHAR(A.DTREF, '/YYYY'), "+ 
    "                                  'A', TO_CHAR(A.DTREF, 'YYYY')), "+
    "          DECODE(':P_PERANALISE', 'M', TO_CHAR(A.DTREF, 'YYYYMM'),  "+
    "                                  'T', TO_CHAR(A.DTREF, 'YYYYQ'),  "+
    "                                  'A', TO_CHAR(A.DTREF, 'YYYY')) "
;

var ORDER_VENDAS_TOTAIS =
    "ORDER BY ORDEM_VENDA"
;

var SQL_FATURAMENTO_ACUMULADO =
     "SELECT DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTVENDA,'MM'), "+
     "                               'T',TO_CHAR(FAT.DTVENDA,'Q'), "+
     "                               'A','1') AS REF_VENDA, "+
     "       DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTVENDA, 'Mon/YYYY'), "+
     "                               'T',TO_CHAR(FAT.DTVENDA, 'Q') ||' Tri'||TO_CHAR(FAT.DTVENDA, '/YYYY'), "+
     "                               'A',TO_CHAR(FAT.DTVENDA, 'YYYY')) AS PER_VENDA, "+
     "       DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTVENDA,'YYYYMM'), "+
     "                               'T',TO_CHAR(FAT.DTVENDA,'YYYYQ'), "+
     "                               'A',TO_CHAR(FAT.DTVENDA,'YYYY')) AS ORDEM_VENDA,"+
     "       DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTFATUR,'MM'), "+
     "                               'T',TO_CHAR(FAT.DTFATUR,'Q'), "+
     "                               'A','1') AS REF_FATUR, "+
     "       DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTFATUR, 'Mon/YYYY'), "+
     "                               'T',TO_CHAR(FAT.DTFATUR, 'Q') ||' Tri'||TO_CHAR(FAT.DTFATUR, '/YYYY'), "+
     "                               'A',TO_CHAR(FAT.DTFATUR, 'YYYY')) AS PER_FATUR, "+
     "       DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTFATUR,'YYYYMM'), "+
     "                               'T',TO_CHAR(FAT.DTFATUR,'YYYYQ'), "+
     "                               'A',TO_CHAR(FAT.DTFATUR,'YYYY')) AS ORDEM_FATUR, "+
     "       TO_CHAR(FAT.DTVENDA, 'YYYY') AS ANO_VENDA,"+
     "       ROUND(SUM(FAT.VALOR),2) AS VALOR "+
     "  FROM CND_FATURAMENTO FAT "+
     " WHERE 1=1 "+
     "   AND TRUNC(FAT.CODNAT,-2) IN (110100,110300,110600,110700,110800,110900) "+
     "   AND (FAT.CODEMP = 10 OR FAT.CODEMP <> 10 AND FAT.NROUNICOBP = 24 OR FAT.CODEMP <> 10 AND FAT.STATUS NOT IN ('R','P','O')) "
;
var GROUP_FATURAMENTO_ACUMULADO =
    "GROUP BY DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTVENDA,'MM'), "+
    "                                 'T',TO_CHAR(FAT.DTVENDA,'Q'), "+
    "                                 'A','1'), /* REF_VENDA */ "+
    "         DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTVENDA, 'Mon/YYYY'), "+
    "                                 'T',TO_CHAR(FAT.DTVENDA, 'Q') ||' Tri'||TO_CHAR(FAT.DTVENDA, '/YYYY'), "+
    "                                 'A',TO_CHAR(FAT.DTVENDA, 'YYYY')),/* PER_VENDA */ "+
    "         DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTVENDA,'YYYYMM'), "+
    "                                 'T',TO_CHAR(FAT.DTVENDA,'YYYYQ'), "+
    "                                 'A',TO_CHAR(FAT.DTVENDA,'YYYY')), /*ORDEM_VENDA*/ "+
    "         DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTFATUR,'MM'), "+
    "                                 'T',TO_CHAR(FAT.DTFATUR,'Q'), "+
    "                                 'A','1'), /* REF_FATUR */ "+
    "         DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTFATUR, 'Mon/YYYY'), "+
    "                                 'T',TO_CHAR(FAT.DTFATUR, 'Q') ||' Tri'||TO_CHAR(FAT.DTFATUR, '/YYYY'), "+
    "                                 'A',TO_CHAR(FAT.DTFATUR, 'YYYY')),/* PER_FATUR */ "+
    "         DECODE(':P_PERANALISE', 'M',TO_CHAR(FAT.DTFATUR,'YYYYMM'), "+
    "                                 'T',TO_CHAR(FAT.DTFATUR,'YYYYQ'), "+
    "                                 'A',TO_CHAR(FAT.DTFATUR,'YYYY')), /* ORDEM_FATUR */"+
    "         TO_CHAR(FAT.DTVENDA, 'YYYY') "
;

var ORDER_FATURAMENTO_ACUMULADO =
    "ORDER BY ORDEM_VENDA, ORDEM_FATUR";

var SQL_DESCR_REFERENCIAS = 
    "SELECT DECODE(':P_PERANALISE', 'M',TO_CHAR(DAT.DATA, 'Mon/YYYY'), "+
    "                               'T',TO_CHAR(DAT.DATA, 'Q') ||' Tri'||TO_CHAR(DAT.DATA, '/YYYY'), "+
    "                               'A',TO_CHAR(DAT.DATA, 'YYYY')) AS PER, "+
    "       DECODE(':P_PERANALISE', 'M',TO_CHAR(DAT.DATA,'YYYYMM'), "+
    "                               'T',TO_CHAR(DAT.DATA,'YYYYQ'), "+
    "                               'A',TO_CHAR(DAT.DATA,'YYYY')) AS ORDEM "+
    "  FROM DATAS DAT "+
    " WHERE 1=1 "+
    "   AND EXTRACT(YEAR FROM DAT.DATA) = :P_DTREF "+
    " GROUP BY DECODE(':P_PERANALISE', 'M',TO_CHAR(DAT.DATA, 'Mon/YYYY'), "+
    "                                  'T',TO_CHAR(DAT.DATA, 'Q') ||' Tri'||TO_CHAR(DAT.DATA, '/YYYY'), "+
    "                                  'A',TO_CHAR(DAT.DATA, 'YYYY')), "+
    "          DECODE(':P_PERANALISE', 'M',TO_CHAR(DAT.DATA,'YYYYMM'), "+
    "                                  'T',TO_CHAR(DAT.DATA,'YYYYQ'), "+
    "                                  'A',TO_CHAR(DAT.DATA,'YYYY')) "+
    " ORDER BY ORDEM "
;
