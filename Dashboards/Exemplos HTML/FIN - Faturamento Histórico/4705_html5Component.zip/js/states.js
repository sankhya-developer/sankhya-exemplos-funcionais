var estados = {
    "tabelaFatAcum":{
        "carregado":"N",
        "visivel":"N" ,
        "periodicidade":{
            "M":{
                "colunas":16,
                "linhas":14
            },
            "T":{
                "colunas":8,
                "linhas":6
            },
            "A":{
                "colunas":5,
                "linhas":3
            }
        }
    }
}