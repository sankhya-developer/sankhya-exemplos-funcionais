/*Este arquivo contem as consultas bases para fornecer dados ao indicador

Observações:
    1 - Os parametros devem ser acrescentado a query conforme necessidade do indicador
    2 - As clausulas que vem depois do WHERE também devem ser acrescentadas depois (GROUP BY, ORDER BY, HABING)
*/ 

var SQL_FATURAMENTO_ACUMULADO = 
    "SELECT DAS.DTVENDA, FAT.DTFATUR, SUM(FAT.VALOR) AS VALOR "+
    "  FROM CND_VENDAS DAS "+
    "       INNER JOIN CND_FATURAMENTO FAT ON FAT.PEDIDO = DAS.PEDIDO "+
    " WHERE 1=1 "+
    "   AND ROWNUM <= 500 ";
