function mostrarLoadingTotVendas(){
    document.getElementById('TotVendasLoading').style.display = 'inline-flex';
}

function ocultarLoadingTotVendas(){
    document.getElementById('TotVendasLoading').style.display = 'none';
}

function mostrarTabelaTotVendas(){
    document.getElementById('TotVendasBody').style.display = 'block';
}

function ocultarTabelaTotVendas(){
    document.getElementById('TotVendasBody').style.display = 'none';
}

function verificaCarregamentoTotVendas(){
    if(props.tabelaTotVendas.carregamento.tituloColunas == "S" && props.tabelaTotVendas.carregamento.valoresVendas == "S" &&
       props.tabelaTotVendas.carregamento.valoresFaturamento == "S"){
        mostrarTabelaTotVendas();
        ocultarLoadingTotVendas();
        //document.getElementById('btnToogleTotVendas').style.display = 'block';
    }
}

function desenhaTabelaTotVendas(dimensoes){
    var html = '<table class="table-hover" border="1" style="white-space: nowrap">';

    for(var i = 0 ; i < dimensoes.linhas ; i++){
        html += '<tr>';
        
        for(var j = 0 ; j < dimensoes.colunas ; j++){
            if(i == 0 && j == 0){
                html += '<td id="tv'+i+'.'+j+'" class="celulaTitulo"></td>';  
            }
            else if (i == 0 && j > 0 || i > 0 && j == 0){
                html += '<td id="tv'+i+'.'+j+'" class="celulaTitulo"></td>'
            }
            else if (i > 0 && j > 0){
                html += '<td id="tv'+i+'.'+j+'" class="celulaCorpo"></td>'
            }
            else{
                html += '<td id="tv'+i+'.'+j+'"></td>';
            }
        }

        html += '</tr>';
    }

    html += '</table>';
    document.getElementById('TotVendasBody').innerHTML = html;
}

function escreveTitulosTotVendas(P_ANOVEND, P_PERANALISE){
    var query = SQL_DESCR_REFERENCIAS;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    query = query.replaceAll(':P_DTREF', P_ANOVEND);
    query = query.replaceAll(':P_PERANALISE', P_PERANALISE);

    executeQuery(query,arr,function(value){
        sleep(100); 
        var dados = JSON.parse(value);

        dados.push({PER:'Total', ORDEM:''});

        for(var i = 1 ; i <= dados.length ; i++ ){
            document.getElementById('tv0.'+i).innerHTML = '<b>'+dados[i-1].PER+'</b>';
        }

        var titulosLinhas = [];
        titulosLinhas.push('Vendas');
        titulosLinhas.push('% Fat');
        titulosLinhas.push('% Fat acum');

        for(var i = 1 ; i <= titulosLinhas.length ; i++ ){
            document.getElementById('tv'+i+'.0').innerHTML = '<b>'+titulosLinhas[i-1]+'</b>';
        }

        props.tabelaTotVendas.carregamento.tituloColunas = "S";
        
        verificaCarregamentoTotVendas();
    }, function(value){
        alert(value);
    });
}

function escreveValoresPorReferenciaTotVendas(dadosVendas, dimensoes){
    var valorAcum = 0;
    var colunaTotal = dimensoes.colunas-1; //coluna com total

    for(var referencia = 1 ; referencia < dimensoes.colunas ; referencia++){

        var valor = getValorVendidoReferencia(dadosVendas, referencia);
        valorAcum += valor;

        document.getElementById('tv1.'+referencia).innerHTML = aplicaMascaraMonetaria(valor);
    }
    document.getElementById('tv1.'+colunaTotal).innerHTML = '<b>'+aplicaMascaraMonetaria(valorAcum)+'</b>';
}

function escrevePercFaturadoTotVendas(dadosVendas, dadosFatur, dimensoes){
    var colunas = dimensoes.colunas-1;
    var linhaFatMes = dimensoes.linhas-2; // linha % Fat no mês
    var linhaFatAcum = dimensoes.linhas-1; // linha % Fat acum

    var vlrFaturReferenciaAcum = 0;
    var vlrVendReferenciaAcum = 0;

    for(var coluna = 1 ; coluna < colunas ; coluna++){
        var vlrVendReferencia = getValorVendidoReferencia(dadosVendas, coluna);
        vlrVendReferenciaAcum += vlrVendReferencia;

        var vlrFaturVendReferencia = getValorFaturadoVendidoReferencia(dadosFatur, coluna, coluna);
        var vlrFaturReferencia = getValorFaturadoReferencia(dadosFatur, coluna);
        vlrFaturReferenciaAcum += vlrFaturReferencia;

        var percFaturReferencia = Math.trunc(f_divisao(vlrFaturVendReferencia,vlrVendReferencia) * 100);
        var percFaturReferenciaAcum = Math.trunc( f_divisao(vlrFaturReferenciaAcum, vlrVendReferenciaAcum) * 100);

        document.getElementById('tv'+linhaFatMes+'.'+coluna).innerHTML = percFaturReferencia+'%';

        if(coluna > 1){
            document.getElementById('tv'+linhaFatAcum+'.'+coluna).innerHTML = percFaturReferenciaAcum+'%';
        }
    }
}

function buscaFaturamentoTotVendas(dadosVendas, P_ANOVEND, P_ANOFATUR, P_PERANALISE, dimensoes){
    var query = SQL_FATURAMENTO_ACUMULADO;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    if(P_ANOVEND != ""){
        query += " AND EXTRACT(YEAR FROM FAT.DTVENDA) = ? ";
        arr.push({value: P_ANOVEND, type:"I"});
    }

    if(P_ANOFATUR != ""){
        query += " AND EXTRACT(YEAR FROM FAT.DTFATUR) = ? ";
        arr.push({value: P_ANOFATUR, type:"I"});
    }

    query += GROUP_FATURAMENTO_ACUMULADO;
    
    query = query.replaceAll(':P_PERANALISE',P_PERANALISE);

    executeQuery(query,arr,function(value){
        sleep(100);

        var dadosFatur = JSON.parse(value);

        escrevePercFaturadoTotVendas(dadosVendas, dadosFatur, dimensoes);

        props.tabelaTotVendas.carregamento.valoresFaturamento = "S";

        verificaCarregamentoTotVendas();
    },function(value){
        alert(value);
    });
}

function montaTotalVendas(P_ANOVEND, P_ANOFATUR, P_PERANALISE){
    mostrarLoadingTotVendas();

    var query = SQL_VENDAS_TOTAIS;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    if(P_ANOVEND != ""){
        query += " AND EXTRACT(YEAR FROM DTREF) = ? "
        arr.push({value: P_ANOVEND, type:"I"});
    }

    query += GROUP_VENDAS_TOTAIS + ORDER_VENDAS_TOTAIS;
    query = query.replaceAll(':P_PERANALISE',P_PERANALISE);

    executeQuery(query,arr,function(value){
        sleep(100);
        
        var dados = JSON.parse(value);
        var dimensoes;

        if (P_PERANALISE == 'M'){dimensoes = props.tabelaTotVendas.periodicidade.M}
        if (P_PERANALISE == 'T'){dimensoes = props.tabelaTotVendas.periodicidade.T}
        if (P_PERANALISE == 'A'){dimensoes = props.tabelaTotVendas.periodicidade.A}

        desenhaTabelaTotVendas(dimensoes);
        
        escreveTitulosTotVendas(P_ANOVEND, P_PERANALISE);

        escreveValoresPorReferenciaTotVendas(dados, dimensoes);

        buscaFaturamentoTotVendas(dados, P_ANOVEND, P_ANOFATUR, P_PERANALISE, dimensoes);

        props.tabelaTotVendas.carregamento.valoresVendas = "S";

        verificaCarregamentoTotVendas();

    },function(value){
        alert(value);
    });
    
}
