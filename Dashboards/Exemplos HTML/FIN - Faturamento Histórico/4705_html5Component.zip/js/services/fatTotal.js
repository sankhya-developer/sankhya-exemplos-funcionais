function mostrarLoadingFatTotal(){
    document.getElementById('FatTotalLoading').style.display = 'inline-flex';
}

function ocultarLoadingFatTotal(){
    document.getElementById('FatTotalLoading').style.display = 'none';
}

function mostrarTabelaFatTotal(){
    document.getElementById('FatTotalBody').style.display = 'block';
}

function ocultarTabelaFatTotal(){
    document.getElementById('FatTotalBody').style.display = 'none';
}

function verificaCarregamentoFatTotal(){
    if(props.tabelaFatTotal.carregamento.tituloColunas == "S"){
        mostrarTabelaFatTotal();
        ocultarLoadingFatTotal();
        //document.getElementById('btnToogleFatTotal').style.display = 'block';
    }
}

function desenhaTabelaFatTotal(arrayAnos, dimensoes){
    var html = '<table class="table-hover" border="1" style="white-space: nowrap">';
    var linhas = [];

    linhas.push('FATURAMENTO');
    for(var i = 1 ; i <= arrayAnos.length ; i++ ){
        linhas.push('Vendas de '+arrayAnos[i]);
    }
    linhas.push('Faturamento Total');

    for(var linha = 0 ; linha < linhas.length ; linha++){
        html += '<tr>';

        for(var coluna = 0 ; coluna < dimensoes.colunas ; coluna ++){
            if(linha == 0 && coluna == 0){
                html += '<td id="ft'+linha+'.'+coluna+'" class="celulaTitulo"><b>Faturamento</b></td>';  
            }
            else if (linha == 0 && coluna > 0 || linha > 0 && coluna == 0){
                html += '<td id="ft'+linha+'.'+coluna+'" class="celulaTitulo"></td>'
            }
            else if (linha > 0 && coluna > 0){
                html += '<td id="ft'+linha+'.'+coluna+'" class="celulaCorpo"></td>'
            }
            else{
                html += '<td id="ft'+linha+'.'+coluna+'"></td>';
            }
        }
        html += '</tr>';
    }
    html += '</table>';
    document.getElementById('FatTotalBody').innerHTML = html;
}

function escreveTitulosFatTotal(P_ANOFATUR, P_PERANALISE, arrayAnos){
    var linhaFatTotal = arrayAnos.length+1;

    var query = SQL_DESCR_REFERENCIAS;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    query = query.replaceAll(':P_DTREF', P_ANOFATUR);
    query = query.replaceAll(':P_PERANALISE', P_PERANALISE);

    executeQuery(query,arr,function(value){
        sleep(100);

        var dados = JSON.parse(value);
        dados.push({PER:'Total', ORDEM:''});

        for(var i = 1 ; i <= dados.length ; i++ ){
            document.getElementById('ft0.'+i).innerHTML = '<b>'+dados[i-1].PER+'</b>';
        }

        for(var i = 1 ; i <= arrayAnos.length ; i++){
            document.getElementById('ft'+i+'.0').innerHTML = '<b>Vendas de '+arrayAnos[i-1]+'</b>';
        }
        document.getElementById('ft'+linhaFatTotal+'.0').innerHTML = '<b>Faturado Total</b>';

        props.tabelaFatTotal.carregamento.tituloColunas = "S";

        verificaCarregamentoFatTotal();
    }, function(value){
        alert(value);
    });
}

function escreveValoresFatTotal(dadosFatur, dimensoes, arrayAnos){
    var valorFatTotal = 0;
    var linhaTotReferencia = arrayAnos.length+1;
    var colunaTotaVend = dimensoes.colunas-1;

    for(var linha = 1 ; linha <= arrayAnos.length ; linha++){
        var totVendAno = 0;

        for(var coluna = 1 ; coluna < dimensoes.colunas ; coluna++){
            document.getElementById('ft'+linha+'.'+coluna).innerHTML = aplicaMascaraMonetaria(getValorFaturadoPorAnoEReferencia(dadosFatur, arrayAnos[linha-1], coluna));
            totVendAno += getValorFaturadoPorAnoEReferencia(dadosFatur, arrayAnos[linha-1], coluna);
        }
        document.getElementById('ft'+linha+'.'+colunaTotaVend).innerHTML = '<b>'+aplicaMascaraMonetaria(totVendAno)+'</b>';
    }

    for(var coluna = 1 ; coluna < dimensoes.colunas ; coluna++){
        valorRefAcum = 0;

        for(var ano = 1 ; ano <= arrayAnos.length ; ano++){
            valorRefAcum += getValorFaturadoPorAnoEReferencia(dadosFatur, arrayAnos[ano], coluna);
        }
        valorFatTotal += valorRefAcum;
        document.getElementById('ft'+linhaTotReferencia+'.'+coluna).innerHTML = '<b>'+aplicaMascaraMonetaria(valorRefAcum)+'</b>';
    }
    document.getElementById('ft'+linhaTotReferencia+'.'+colunaTotaVend).innerHTML = '<b>'+aplicaMascaraMonetaria(valorFatTotal)+'</b>';
}

function getValorFaturadoPorAnoEReferencia(dadosFatur, ano, referencia){
    var valor = 0;

    for(var i = 0 ; i < dadosFatur.length ; i++){
        if(dadosFatur[i].ANO_VENDA == ano && dadosFatur[i].REF_FATUR == referencia){
            valor += Number(dadosFatur[i].VALOR);
        }
    }

    return valor;
}

function montaFatTotal(P_ANOVEND, P_ANOFATUR, P_PERANALISE){
    mostrarLoadingFatTotal();
    sleep(300);

    var dimensoes;

    if (P_PERANALISE == 'M'){dimensoes = props.tabelaFatTotal.periodicidade.M}
    if (P_PERANALISE == 'T'){dimensoes = props.tabelaFatTotal.periodicidade.T}
    if (P_PERANALISE == 'A'){dimensoes = props.tabelaFatTotal.periodicidade.A}

    /* busca dados de faturamento*/
    var query = SQL_FATURAMENTO_ACUMULADO;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    if(P_ANOFATUR != ""){
        query += " AND EXTRACT(YEAR FROM FAT.DTFATUR) = ? ";
        arr.push({value: P_ANOFATUR, type:"I"});
    }

    query += GROUP_FATURAMENTO_ACUMULADO + ' ORDER BY ANO_VENDA ';
    
    query = query.replaceAll(':P_PERANALISE',P_PERANALISE);

    executeQuery(query,arr,function(value){
        var dadosFatur = JSON.parse(value);
        sleep(100);

        var arrayAnos = [];

        for(var i = 0 ; i < dadosFatur.length ; i++){
        
            if(!arrayAnos.includes(dadosFatur[i].ANO_VENDA)){
                arrayAnos.push(dadosFatur[i].ANO_VENDA);
            }
        }

        desenhaTabelaFatTotal(arrayAnos, dimensoes);
        escreveTitulosFatTotal(P_ANOFATUR, P_PERANALISE, arrayAnos);
        escreveValoresFatTotal(dadosFatur, dimensoes, arrayAnos);

    },function(value){
        alert(value);
    });

};
