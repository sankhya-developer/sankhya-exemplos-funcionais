function mostrarLoadingFatAcum(){
    document.getElementById('FatAcumLoading').style.display = 'inline-flex';
}

function ocultarLoadingFatAcum(){
    document.getElementById('FatAcumLoading').style.display = 'none';
}

function mostrarTabelaFatAcum(){
    document.getElementById('FatAcumBody').style.display = 'block';
}

function ocultarTabelaFatAcum(){
    document.getElementById('FatAcumBody').style.display = 'none';
}

function verificaCarregamentoFatAcum(){
    if(props.tabelaFatAcum.carregamento.tituloColunas == "S" && props.tabelaFatAcum.carregamento.tituloLinhas == "S" &&
    props.tabelaFatAcum.carregamento.valoresFaturamento == "S" && props.tabelaFatAcum.carregamento.percFaturado == "S" ){
        mostrarTabelaFatAcum();
        ocultarLoadingFatAcum();
        //document.getElementById('btnToogleFatAcum').style.display = 'block';
    }
}

function escreveTitulosLinhasColunas(P_ANOVEND, P_ANOFATUR, P_PERANALISE){

    var queryFatur = SQL_DESCR_REFERENCIAS;
    var arrFatur=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    queryFatur = queryFatur.replaceAll(':P_DTREF', P_ANOFATUR);
    queryFatur = queryFatur.replaceAll(':P_PERANALISE', P_PERANALISE);

    executeQuery(queryFatur,arrFatur,function(value){
        sleep(200);      
        /* titulos colunas (faturamento) - inicio */
        var dados = JSON.parse(value);

        dados.push({PER:'Total vendido', ORDEM:''})
        dados.push({PER:'% Faturado', ORDEM:''});
        dados.push({PER:'Delta', ORDEM:''});

        for(i = 1 ; i <= dados.length ; i++){
            document.getElementById('0.'+i).innerHTML = '<b>'+dados[i-1].PER+'</b>';
        }

        props.tabelaFatAcum.carregamento.tituloColunas = "S";
        /* titulos colunas (faturamento) - fim */

        /* titulos colunas (venda) - inicio */
        var queryVenda = SQL_DESCR_REFERENCIAS;
        var arrVenda=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

        queryVenda = queryVenda.replaceAll(':P_DTREF', P_ANOVEND);
        queryVenda = queryVenda.replaceAll(':P_PERANALISE', P_PERANALISE);

        verificaCarregamentoFatAcum();
        

        executeQuery(queryVenda,arrVenda,function(value){
            sleep(200);
            var dados = JSON.parse(value);

            dados.push({PER:'Total faturado', ORDEM:''});

            for(i = 1 ; i <= dados.length ; i++){
                document.getElementById(i+'.0').innerHTML = '<b>'+dados[i-1].PER+'</b>';
            }

            props.tabelaFatAcum.carregamento.tituloLinhas = "S";

            verificaCarregamentoFatAcum();

        },function(value){
            alert(value);
        });
        /* titulos colunas (venda) - fim */
    },function(value){
        alert(value);
    });
}

function desenhaTabelaFatAcum (dimensoes){
    var html = '<table class="table-hover" border="1" style="white-space: nowrap">'

    /* estrutura do corpo - inicio */
    for(i = 0 ; i < dimensoes.linhas ; i++ ){
        html += '<tr>'

        for(j = 0 ; j < dimensoes.colunas ; j++){
            if(i == 0 && j == 0){
                html += '<td id="'+i+'.'+j+'" class="celulaTitulo"></td>';  
            }
            else if (i == 0 && j > 0 || i > 0 && j == 0){
                html += '<td id="'+i+'.'+j+'" class="celulaTitulo"></td>'
            }
            else if (i > 0 && j > 0){
                html += '<td id="'+i+'.'+j+'" class="celulaCorpo"></td>'
            }
            else {
                html += '<td id="'+i+'.'+j+'"></td>'
            }
        }
        html += '</tr>';
    }

    html += '</table>'
    document.getElementById('FatAcumBody').innerHTML = html;
    /* estrutura do corpo - fim */

}

function escreveValoresPorReferencia(dados, dimensoes){

    for(var linha = 1 ; linha < dimensoes.linhas ; linha++){
        for(var coluna = 1 ; coluna < dimensoes.colunas ; coluna++){

            var valor = getValorFaturadoVendidoReferencia(dados, linha, coluna); 

            document.getElementById(linha+'.'+coluna).innerHTML = aplicaMascaraMonetaria(valor);
        }
    }
}

function calculaTotFaturNaReferencia(dados, coluna, dimensoes){
    var linhaTotFat = dimensoes.linhas-1; //linha total de faturamento
    var valor = 0;

    for(var j = 0 ; j < linhaTotFat ; j++){
        valor += getValorFaturadoVendidoReferencia(dados, j, coluna);
    }

    return valor;
}

function calculaTotVendasFaturadasNaReferencia(dados, linha, dimensoes){
    var colunaTotVend = dimensoes.colunas-3; //coluna total de vendas
    var valor = 0;

    for(var j = 0 ; j < colunaTotVend ; j++){            
        valor += getValorFaturadoVendidoReferencia(dados, linha, j)
    }

    return valor
}

function escrevePercFaturado(dadosFatur, dadosVendasTotais, dimensoes){
    var linhaTotFat = dimensoes.linhas-1
    var colunaTotVend = dimensoes.colunas-2 // coluna % Faturado

    for(var linha = 1 ; linha < linhaTotFat ; linha++){
        var vendasFaturadasNaReferencia = calculaTotVendasFaturadasNaReferencia(dadosFatur, linha, dimensoes);
        var vendidoNaReferencia = calculaTotVendasNaReferencia(dadosVendasTotais, linha);
        var percFaturado = Math.trunc(f_divisao(vendasFaturadasNaReferencia, vendidoNaReferencia) * 100);
        var delta = vendidoNaReferencia - vendasFaturadasNaReferencia
        document.getElementById(linha+'.'+colunaTotVend).innerHTML = '<b>'+percFaturado+'%</b>';
    }
}

function escreveDelta(dadosFatur, dadosVendasTotais, dimensoes){
    var linhaTotFat = dimensoes.linhas-1
    var colunaTotVend = dimensoes.colunas-1 // coluna Delta
    var deltaAcum = 0;

    for(var linha = 1 ; linha < linhaTotFat ; linha++){
        var vendasFaturadasNaReferencia = calculaTotVendasFaturadasNaReferencia(dadosFatur, linha, dimensoes);
        var vendidoNaReferencia = calculaTotVendasNaReferencia(dadosVendasTotais, linha);

        var delta = vendidoNaReferencia - vendasFaturadasNaReferencia
        delta = delta*-1

        deltaAcum += delta;
        document.getElementById(linha+'.'+colunaTotVend).innerHTML = '<b>'+aplicaMascaraMonetaria(delta)+'</b>';
    }
    document.getElementById(linhaTotFat+'.'+colunaTotVend).innerHTML = '<b>'+aplicaMascaraMonetaria(deltaAcum)+'</b>';
}

function buscaDadosPercFaturado(dadosFatur, dimensoes, P_ANOVEND, P_PERANALISE){
    var query = SQL_VENDAS_TOTAIS;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    if(P_ANOVEND != ""){
        query += " AND EXTRACT(YEAR FROM DTREF) = ? ";
        arr.push({value: P_ANOVEND, type:"I"});
    }

    query += GROUP_VENDAS_TOTAIS + ORDER_VENDAS_TOTAIS;
    query = query.replaceAll(':P_PERANALISE',P_PERANALISE);

    executeQuery(query,arr,function(value){
        sleep(200);
        var dadosVendasTotais = JSON.parse(value);

        escrevePercFaturado(dadosFatur, dadosVendasTotais, dimensoes);
        escreveDelta(dadosFatur, dadosVendasTotais, dimensoes);
        escreveTotalizadores(dadosFatur, dadosVendasTotais, dimensoes);

        props.tabelaFatAcum.carregamento.percFaturado = "S";

        verificaCarregamentoFatAcum();
    },function(value){
        alert(value);
    }); 

}

function calculaTotVendasNaReferencia(dados, linha){
    var valor = getValorVendidoReferencia(dados, linha);

    return valor;
}

function escreveTotalizadores(dadosFatur, dadosVendasTotais, dimensoes){
    linhaTotFat = dimensoes.linhas-1; //linha total de faturamento
    colunaTotVend = dimensoes.colunas-3; //coluna total de vendas
    colunaTotPercFat = dimensoes.colunas-2; // coluna total de perc faturado
    var valorFatAcum = 0;
    var valorVendAcum = 0;

    /* escreve totalizador de vendas - inicio */
    for(var linha = 1 ; linha < colunaTotVend ; linha++){
        document.getElementById(linha+'.'+colunaTotVend).innerHTML = '<b>'+aplicaMascaraMonetaria(calculaTotVendasFaturadasNaReferencia(dadosFatur, linha, dimensoes))+'</b>';
    }
    /* escreve totalizador de vendas - fim */

    /* escreve totalizador de faturamento - inicio */
    for(var coluna = 1 ; coluna < linhaTotFat ; coluna++){
        document.getElementById(linhaTotFat+'.'+coluna).innerHTML = '<b>'+aplicaMascaraMonetaria(calculaTotFaturNaReferencia(dadosFatur, coluna, dimensoes))+'</b>';
        valorFatAcum += calculaTotFaturNaReferencia(dadosFatur, coluna, dimensoes);
    }
    document.getElementById(linhaTotFat+'.'+linhaTotFat).innerHTML = '<b>'+aplicaMascaraMonetaria(valorFatAcum)+'</b>';
    /* escreve totalizador de faturamento - fim */

    for(var i = 0 ; i < colunaTotVend ; i++){
        valorVendAcum += calculaTotVendasNaReferencia(dadosVendasTotais, i);
    }

    document.getElementById(linhaTotFat+'.'+colunaTotPercFat).innerHTML = '<b>'+Math.trunc(f_divisao(valorFatAcum, valorVendAcum)*100)+'%</b>';
}

function montaFaturamentoAcumulado(P_ANOVEND, P_ANOFATUR, P_PERANALISE){
    mostrarLoadingFatAcum();

    var query = SQL_FATURAMENTO_ACUMULADO;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    if(P_ANOVEND != ""){
        query += " AND EXTRACT(YEAR FROM FAT.DTVENDA) = ? ";
        arr.push({value: P_ANOVEND, type:"I"});
    }

    if(P_ANOFATUR != ""){
        query += " AND EXTRACT(YEAR FROM FAT.DTFATUR) = ? ";
        arr.push({value: P_ANOFATUR, type:"I"});
    }

    query += GROUP_FATURAMENTO_ACUMULADO + ORDER_FATURAMENTO_ACUMULADO;
    
    query = query.replaceAll(':P_PERANALISE',P_PERANALISE);

    executeQuery(query,arr,function(value){
        sleep(200);
        
        var dadosFatur = JSON.parse(value);
        var dimensoes;

        if (P_PERANALISE == 'M'){dimensoes = props.tabelaFatAcum.periodicidade.M}
        if (P_PERANALISE == 'T'){dimensoes = props.tabelaFatAcum.periodicidade.T}
        if (P_PERANALISE == 'A'){dimensoes = props.tabelaFatAcum.periodicidade.A}

        desenhaTabelaFatAcum(dimensoes);

        escreveTitulosLinhasColunas(P_ANOVEND, P_ANOFATUR, P_PERANALISE); 

        escreveValoresPorReferencia(dadosFatur, dimensoes); 

        buscaDadosPercFaturado(dadosFatur, dimensoes, P_ANOVEND, P_PERANALISE);

        props.tabelaFatAcum.carregamento.valoresFaturamento = "S";

        verificaCarregamentoFatAcum();

    },function(value){
        alert(value);
    });

}