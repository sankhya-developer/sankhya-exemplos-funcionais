function mostrarLoadingFatHistorico(){
    document.getElementById('FatHistLoading').style.display = 'inline-flex';
}

function ocultarLoadingFatHistorico(){
    document.getElementById('FatHistLoading').style.display = 'none';
}

function mostrarTabelaFatHistorico(){
    document.getElementById('FatHistBody').style.display = 'block';
}

function ocultarTabelaFatHistorico(){
    document.getElementById('FatHistBody').style.display = 'none';
}

function verificaCarregamentoFatHistorico(){

    if(props.tabelaFatHistorico.carregamento.tituloColunas == "S" && props.tabelaFatHistorico.carregamento.dadosBase == "S" &&
       props.tabelaFatHistorico.carregamento.cancelamento == "S"){
        mostrarTabelaFatHistorico();
        ocultarLoadingFatHistorico();
        //document.getElementById('btnToogleFatHist').style.display = 'block';
    }
}

function desenhaTabelaFatHistorico(dimensoes){
    var html = '<table class="table-hover" border="1" style="white-space: nowrap">';

    for(var i = 0 ; i < dimensoes.linhas ; i++){
        html += '<tr>';
        
        for(var j = 0 ; j < dimensoes.colunas ; j++){
            if(i == 0 && j == 0){
                html += '<td id="fh'+i+'.'+j+'" class="celulaTitulo"></td>';  
            }
            else if (i == 0 && j > 0 || i > 0 && j == 0){
                html += '<td id="fh'+i+'.'+j+'" class="celulaTitulo"></td>'
            }
            else if (i > 0 && j > 0){
                html += '<td id="fh'+i+'.'+j+'" class="celulaCorpo"></td>'
            }
            else{
                html += '<td id="fh'+i+'.'+j+'"></td>';
            }
        }
        html += '</tr>';
    }

    html += '</table>';
    document.getElementById('FatHistBody').innerHTML = html;

}

function escreveTitutlosFatHistorico(P_ANOFATUR, P_PERANALISE){
    var query = SQL_DESCR_REFERENCIAS;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    query = query.replaceAll(':P_DTREF', P_ANOFATUR);
    query = query.replaceAll(':P_PERANALISE', P_PERANALISE);

    executeQuery(query,arr,function(value){
        sleep(200); 
        var dados = JSON.parse(value);

        for(var i = 1 ; i <= dados.length ; i++ ){
            document.getElementById('fh0.'+i).innerHTML = '<b>'+dados[i-1].PER+'</b>';
        }

        var titulosLinhas = [];
        titulosLinhas.push('Faturamento acumulado');
        titulosLinhas.push('Vendido acumulado');
        titulosLinhas.push('GAP faturamento');
        titulosLinhas.push('GAP referencia atual');
        titulosLinhas.push('GAP referencias anteriores');
        titulosLinhas.push('GAP fat/venda referencia');
        titulosLinhas.push('Cancelamento acumulado');

        for(var i = 1 ; i <= titulosLinhas.length ; i++ ){
            document.getElementById('fh'+i+'.0').innerHTML = '<b>'+titulosLinhas[i-1]+'</b>';
        }

        props.tabelaFatHistorico.carregamento.tituloColunas = "S";
        
        verificaCarregamentoFatHistorico();
    }, function(value){
        alert(value);
    });
}

function BuscaDadosValoresBaseFatHistorico(P_ANOVEND, P_ANOFATUR, P_PERANALISE, dimensoes){
    sleep(200);
    var query = SQL_VENDAS_TOTAIS;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    if(P_ANOVEND != ""){
        query += " AND EXTRACT(YEAR FROM DTREF) = ? "
        arr.push({value: P_ANOVEND, type:"I"});
    }

    query += GROUP_VENDAS_TOTAIS + ORDER_VENDAS_TOTAIS;
    query = query.replaceAll(':P_PERANALISE',P_PERANALISE);

    executeQuery(query,arr,function(value){
        /* busca dados de venda */
        var dadosVenda = JSON.parse(value);
        sleep(200);

        /* busca dados de faturamento*/
        var query = SQL_FATURAMENTO_ACUMULADO;
        var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

        if(P_ANOVEND != ""){
            query += " AND EXTRACT(YEAR FROM FAT.DTVENDA) = ? ";
            arr.push({value: P_ANOVEND, type:"I"});
        }

        if(P_ANOFATUR != ""){
            query += " AND EXTRACT(YEAR FROM FAT.DTFATUR) = ? ";
            arr.push({value: P_ANOFATUR, type:"I"});
        }

        query += GROUP_FATURAMENTO_ACUMULADO + ORDER_FATURAMENTO_ACUMULADO;
        
        query = query.replaceAll(':P_PERANALISE',P_PERANALISE);

        verificaCarregamentoFatHistorico();

        executeQuery(query,arr,function(value){
            var dadosFatur = JSON.parse(value);
            sleep(200);

            escreveValoresBaseFatHistorico(dadosVenda, dadosFatur, dimensoes);

            verificaCarregamentoFatHistorico();
        },function(value){
        
        });

    },function(value){
        alert(value);
    });

}

function escreveValoresBaseFatHistorico(dadosVenda, dadosFatur, dimensoes){
    var valorFatAcum = 0;
    var valorVendAcum = 0;
    
    for(var referencia = 1 ; referencia < dimensoes.colunas ; referencia++){

        var valorFat = getValorFaturadoReferencia(dadosFatur, referencia);
        valorFatAcum += valorFat;

        var valorVend = getValorVendidoReferencia(dadosVenda, referencia);
        valorVendAcum += valorVend;

        var valorGAPmes = valorVendAcum - valorFatAcum;

        var valorGAPfaturadoMes = valorVend - getValorFaturadoVendidoReferencia(dadosFatur, referencia, referencia);

        var valorGAPrefsAnteriores = valorGAPmes - valorGAPfaturadoMes;

        var valorGAPfatVendMes = Math.trunc(f_divisao((valorVendAcum-valorFatAcum), valorVend) * 100);
        
        document.getElementById('fh1.'+referencia).innerHTML = aplicaMascaraMonetaria(valorFatAcum);
        document.getElementById('fh2.'+referencia).innerHTML = aplicaMascaraMonetaria(valorVendAcum);
        document.getElementById('fh3.'+referencia).innerHTML = aplicaMascaraMonetaria(valorGAPmes);
        document.getElementById('fh4.'+referencia).innerHTML = aplicaMascaraMonetaria(valorGAPfaturadoMes);
        document.getElementById('fh5.'+referencia).innerHTML = aplicaMascaraMonetaria(valorGAPrefsAnteriores);
        document.getElementById('fh6.'+referencia).innerHTML = valorGAPfatVendMes+'%';
        
        props.tabelaFatHistorico.carregamento.dadosBase = "S";
    }
    
}

function BuscaDadosCancelamento(P_ANOVEND, P_PERANALISE, dimensoes){
    sleep(200);

    var query = SQL_VENDAS_CANCELADAS;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    if(P_ANOVEND != ""){
        query += " AND EXTRACT(YEAR FROM DTREF) = ? "
        arr.push({value: P_ANOVEND, type:"I"});
    }

    query += GROUP_VENDAS_CANCELADAS;
    query = query.replaceAll(':P_PERANALISE',P_PERANALISE);

    executeQuery(query,arr,function(value){
        sleep(200);

        var dados = JSON.parse(value);

        var valorCanceladoAcum = 0;

        for(var referencia = 1 ; referencia < dimensoes.colunas ; referencia++){
            var valorCancelado = getValorVendidoReferencia(dados, referencia);
            valorCanceladoAcum += valorCancelado;
            
            document.getElementById('fh7.'+referencia).innerHTML = aplicaMascaraMonetaria(valorCanceladoAcum); 
        }
        props.tabelaFatHistorico.carregamento.cancelamento = "S"

        verificaCarregamentoFatHistorico();
    }, function(value){
        alert(value);
    });

}

function montaFatHistorico(P_ANOVEND, P_ANOFATUR, P_PERANALISE){
    mostrarLoadingFatHistorico();
    sleep(300);

    var dimensoes;

    if (P_PERANALISE == 'M'){dimensoes = props.tabelaFatHistorico.periodicidade.M}
    if (P_PERANALISE == 'T'){dimensoes = props.tabelaFatHistorico.periodicidade.T}
    if (P_PERANALISE == 'A'){dimensoes = props.tabelaFatHistorico.periodicidade.A}
  
    desenhaTabelaFatHistorico(dimensoes);

    escreveTitutlosFatHistorico(P_ANOFATUR, P_PERANALISE);

    BuscaDadosValoresBaseFatHistorico(P_ANOVEND, P_ANOFATUR, P_PERANALISE, dimensoes);
    
    BuscaDadosCancelamento(P_ANOVEND, P_PERANALISE, dimensoes);

}