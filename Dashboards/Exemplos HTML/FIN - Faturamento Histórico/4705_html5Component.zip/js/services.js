function montaFaturamentoAcumulado(P_ANOVEND, P_ANOFATUR, P_PERANALISE){
    
    var query = SQL_FATURAMENTO_ACUMULADO;
    var arr=[{value:"", type:"IN"}]; //OBRIGATORIO PARA FUNCIONAR

    if(P_ANOVEND != ""){
        query += " AND EXTRACT(YEAR FROM DAS.DTVENDA) = ? ";
        arr.push({value: P_ANOVEND, type:"I"});
    }

    if(P_ANOFATUR != ""){
        query += " AND EXTRACT(YEAR FROM FAT.DTFATUR) = ? ";
        arr.push({value: P_ANOFATUR, type:"I"});
    }

    query += GROUP_FATURAMENTO_ACUMULADO + ORDER_FATURAMENTO_ACUMULADO;
    
    query = query.replaceAll(':P_PERANALISE',P_PERANALISE)

    console.log(query);

    if(props.tabelaFatAcum.visivel == 'N' && props.tabelaFatAcum.carregado == 'N'){
        
        executeQuery(query,arr,function(value){
            var dados = JSON.parse(value);
            
            desenhaTabelaFatAcum(dados, P_PERANALISE);
    
        },function(value){
            alert(value);
        });

        document.getElementById('fatHistoricoFooter').style.display = 'block';
        document.getElementById('fatHistoricoBody').style.display = 'block';
        
        props.tabelaFatAcum.visivel = 'S';
        props.tabelaFatAcum.carregado = 'S';

    } else if(props.tabelaFatAcum.visivel == 'N' && props.tabelaFatAcum.carregado == 'S'){

        document.getElementById('fatHistoricoFooter').style.display = 'block';
        document.getElementById('fatHistoricoBody').style.display = 'block';
        
        props.tabelaFatAcum.visivel = 'S';

    } else if (props.tabelaFatAcum.visivel == 'S' && props.tabelaFatAcum.carregado == 'S'){
        document.getElementById('fatHistoricoFooter').style.display = 'none';
        document.getElementById('fatHistoricoBody').style.display = 'none';
        
        props.tabelaFatAcum.visivel = 'N';
    }

}

function desenhaTabelaFatAcum (dados, P_PERANALISE){
    var html = '<table border="1" style="white-space: nowrap">'
    var dimensoes;
    var tituloColunas = [];
    var tituloLinhas = [];

    if (P_PERANALISE == 'M'){dimensoes = props.tabelaFatAcum.periodicidade.M}
    if (P_PERANALISE == 'T'){dimensoes = props.tabelaFatAcum.periodicidade.T}
    if (P_PERANALISE == 'A'){dimensoes = props.tabelaFatAcum.periodicidade.A}

    for(i = 0 ; i < dados.length ; i++){
        tituloColunas.push(dados[i].PER_VENDA);
    }
    tituloColunas = [ ...new Set( tituloColunas ) ];
    tituloColunas.push('Total');
    tituloColunas.push('% Faturado');
    tituloColunas.push('Delta');
    
    for(i = 0 ; i < dados.length ; i++){
        tituloLinhas.push(dados[i].PER_FATUR);
    }
    tituloLinhas = [ ...new Set( tituloLinhas ) ];
    tituloLinhas.push('Faturamento total');


    /* estrutura do corpo - inicio */
    for(i = 0 ; i < dimensoes.linhas ; i++ ){
        html += '<tr>'

        for(j = 0 ; j < dimensoes.colunas ; j++){
            if(i == 0 && j == 0){
                html += '<td id="'+i+'-'+j+'"></td>';  
            }else{
                html += '<td id="'+i+'-'+j+'">R$ 0,00</td>'
            }
        }

        html += '</tr>';
    }

    html += '</table>'
    document.getElementById('fatHistoricoBody').innerHTML = html;
    /* estrutura do corpo - fim */

    /* preenchendo titulos colunas (venda) - inicio */
    for(i = 1 ; i <= tituloColunas.length ; i++){
        document.getElementById('0-'+i).innerHTML = '<b>'+tituloColunas[i-1]+'</b>';
    }

    /* preenchendo titulos colunas (venda) - fim */

    /* preenchendo titulos linhas (faturamento) - inicio */
     for(i = 1 ; i <= tituloLinhas.length ; i++){
        document.getElementById(i+'-0').innerHTML = '<b>'+tituloLinhas[i-1]+'</b>';
    }
    /* preenchendo titulos linhas (faturamento) - fim */

    console.log(dados)


    /* corpo 
    for(ref_venda = 0 ; ref_venda <= 12 ; ref_venda++ ){
        html += '<tr>'
        
        html += '<td><b>'+dados[ref_venda].PER_FATUR+'</b></td>';
        
        for(var ref_fatur = 1 ; ref_fatur <= 12 ; ref_fatur++){
            html +='<td>'+getValor(dados, ref_venda, ref_fatur)+'</td>';
        }
        html += '</tr>'
    }
    */

    
}

function getValor(ds, ref_venda, ref_fatur){
    var valor = 0;
    
    for (i = 0 ; i < ds.length ; i++){
        if (ds[i].REF_VENDA == ref_venda && ds[i].REF_FATUR == ref_fatur){
            return ds[i].VALOR;
        }
    }
    
    return valor;
}
