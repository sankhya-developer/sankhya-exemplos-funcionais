function montaMarcosJornada(marcosJornadaJSON, daysValidation) {
  var qtdCampos = marcosJornadaJSON.camposMarcosJornada.length-1;
  var html = '';
  var montaBox = '';
  var montaArrowSteps = '';

  for (i = 1; i <= qtdCampos; i++) {
    if (marcosJornadaJSON.camposMarcosJornada[i].data == ' ') {
      montaBox += '<div class="box-titulo apagado"><span class="step-titulo">' + marcosJornadaJSON.camposMarcosJornada[i].descricao + '</span></div>';
      montaArrowSteps += '<div class="step apagado"><span>' + marcosJornadaJSON.camposMarcosJornada[i].data + '</span></div>';
    } else {
      montaBox += '<div class="box-titulo"><span class="step-titulo">' + marcosJornadaJSON.camposMarcosJornada[i].descricao + '</span></div>';
      montaArrowSteps += '<div class="step"><span>' + marcosJornadaJSON.camposMarcosJornada[i].data + '</span></div>';
    }
  }
  html = '<div class="box">' + montaBox + '</div>' + '<div class="arrow-steps">' + montaArrowSteps + '</div>'
  html += '</br></br><div id="timelineDayLines"></div>'
  html += '</br></br></br><div id="timelineCardsContainer"></div>'
  document.getElementById("marcosJornada").innerHTML = html;

  montaDayLines(daysValidation);
}

function montaDayLines(daysValidation){
  var html = '';
  html = '<table border="0" class="dayLinesTable">'+
            '<tr>'+
              '<td style="width: 314px"><div class="linhaMomento1"></div></td>'+
              '<td style="width: 105px"></td>'+
              '<td style="width: 314px"><div class="linhaMomento2"></div></td>'+
              '<td style="width: 105px"><div class="linhaMomento3"></div></td>'+
              '<td style="width: 105px"><div class="linhaMomento4"></div></td>'+
              '<td style="width: 205px"><div class="linhaMomento5"></div></td>'+
            '</tr>'+
            '<tr>'+
              '<td class="textoLinhaMomento1">'+daysValidation.diasMomento1+'</td>'+
              '<td></td>'+
              '<td class="textoLinhaMomento2">'+daysValidation.diasMomento2+'</td>'+
              '<td class="textoLinhaMomento3">'+daysValidation.diasMomento3+'</td>'+
              '<td class="textoLinhaMomento4">'+daysValidation.diasMomento4+'</td>'+
              '<td class="textoLinhaMomento5">'+daysValidation.diasMomento5+'</td>'+
            '</tr>'+
          '</table>';
  document.getElementById('timelineDayLines').innerHTML = html;

  for(var i = 1 ; i <= 5 ; i++){
    validaMomento(daysValidation, i);
  }  
}

function validaMomento(daysValidation, idMomento){
  var linha = document.getElementsByClassName('linhaMomento'+idMomento)[0];
  var texto = document.getElementsByClassName('textoLinhaMomento'+idMomento)[0];
  var dias;

  if(idMomento == 1){dias = daysValidation.diasMomento1}
  if(idMomento == 2){dias = daysValidation.diasMomento2}
  if(idMomento == 3){dias = daysValidation.diasMomento3}
  if(idMomento == 4){dias = daysValidation.diasMomento4}
  if(idMomento == 5){dias = daysValidation.diasMomento5} 

  if(dias == ''){
    linha.style.opacity = '0.1';
    texto.style.opacity = '0.1';
  }

}