function montaGraficoEtapa (queryInfosEtapaJSON) {
  var qtdCampos = queryInfosEtapaJSON.camposEtapa.length - 1;
  var linha = '<div class="linha-jornada"></div>';
  var idGrafico = ''
  var circle = '';
  var codEtapa = '';
  var percApresentacao = '';
  var nomeEtapa = '';

  for (i = 1; i <= qtdCampos; i++) {
    idGrafico = 'circleEtapa' + queryInfosEtapaJSON.camposEtapa[i].codEtapa;
    codEtapa = queryInfosEtapaJSON.camposEtapa[i].codEtapa;
    percApresentacao = queryInfosEtapaJSON.camposEtapa[i].percApresentacao;
    nomeEtapa = queryInfosEtapaJSON.camposEtapa[i].nomeEtapa;

    circle += '<div class="box-jornada"><div class="percent-jornada" onclick="onClickEtapa(\''+ codEtapa + '\')"><svg><circle></circle><circle id="' + idGrafico + '"></circle></svg><div class="number-jornada"><h2>' + percApresentacao + '</h2></div></div><h2 class="text-jornada">' + nomeEtapa + '</h2></div>';
  }

  document.getElementById('containerEtapas').innerHTML = linha + circle;
  corGraficoEtapa(queryInfosEtapaJSON);
}

function corGraficoEtapa(queryInfosEtapaJSON) {
  var qtdCampos = queryInfosEtapaJSON.camposEtapa.length - 1;
  var idGrafico = '';
  var realPerc = '';
  var faixa = '';

  for (j = 1; j <= qtdCampos; j++) {
    idGrafico = 'circleEtapa' + queryInfosEtapaJSON.camposEtapa[j].codEtapa;
    faixa = queryInfosEtapaJSON.camposEtapa[j].faixa;
    realPerc = queryInfosEtapaJSON.camposEtapa[j].realPerc;

    if (realPerc.length == 0) {
      document.getElementById(idGrafico).style.strokeDashoffset = '440';
    } else {
      document.getElementById(idGrafico).style.strokeDashoffset = 'calc(220 - (220 *' + realPerc + ') / 100)';
    }

    if (faixa == 'Vermelho') {
      document.getElementById(idGrafico).style.stroke = '#C1272D';
    } else if (faixa == 'Amarelo') {
      document.getElementById(idGrafico).style.stroke = '#FCEE21';
    } else if (faixa == 'Verde') {
      document.getElementById(idGrafico).style.stroke = '#A2C617';
    } else if (faixa == 'Azul') {
      document.getElementById(idGrafico).style.stroke = '#0063A6';
    } else {
      document.getElementById(idGrafico).style.stroke = '#CCC';
    }
  }
}