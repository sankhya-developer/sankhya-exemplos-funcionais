async function montaTimelineCard(validation,card1,card2,card3,card4,card5){

    if(validation.card1 == "S"){
        construirCard(1);
        escreverTituloCard(1, 'VENDA INICIAL');
        escreverCorpoCard(1,card1);
    }

    if(validation.card2== 'S'){
        construirCard(2);
        escreverTituloCard(2, 'PROJETO INICIAL');
        escreverCorpoCard(2,card2);
    }

    if(validation.card3 == 'S'){
        construirCard(3);
        escreverTituloCard(3, 'EVOLUÇÃO');
        escreverCorpoCard(3,card3);
    }
    if(validation.card4 == 'S'){
        construirCard(4);
        escreverTituloCard(4, 'VENDA BASE');
        escreverCorpoCard(4,card4);
    }
    if(validation.card5 == 'S'){
        construirCard(5);
        escreverTituloCard(5, 'PROJETO ADICIONAL');
        escreverCorpoCard(5,card5);
    }
}

function construirCard(idCard){
    cardHTML = '<div id="timelineCard'+idCard+'" class="timelineCard"><div id="card'+idCard+'title"></div><div id="card'+idCard+'body"></div></div>'
    document.getElementById('timelineCardsContainer').innerHTML += cardHTML;
    document.getElementById('card'+idCard+'title').classList.add('timelineCardTitle','corMomento'+idCard);
    document.getElementById('card'+idCard+'body').classList.add('timelineCardBody');

}

function escreverTituloCard(idCard, titulo){
    document.getElementById('card'+idCard+'title').innerHTML = titulo;
}

function escreverCorpoCard(idCard, elements){
    var idCorpo = 'card'+idCard+'body';
    var cardBodyHTML = '';

    var array = convertJsonToArray(elements)[0];

    for(var i = 2 ; i < array.length ; i++){
        cardBodyHTML += '<b>'+array[i].titulo+':</b> '+array[i].valor+'</br>';
    }
    document.getElementById(idCorpo).innerHTML = cardBodyHTML;
}

function convertJsonToArray(JsonObject){
    let array = [];

    for(const i in JsonObject){
        if(JsonObject.hasOwnProperty(i)){
            array.push(JsonObject[i]);
        }
    }

    return array;
}