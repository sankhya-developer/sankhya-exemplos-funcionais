function montaTabelaPainelGeral (queryInfosParceiroJSON) {

  var qtdCampos = queryInfosParceiroJSON.camposTabela.length;
  var montaTabela = '';
  var montaLinhaTitulo = '<div class="div-table-row">';
  var montaLinhaValor = '<div class="div-table-row">';
  
  for(i = 1; i < qtdCampos ; i++){
    montaLinhaTitulo += '<div class="div-table-cell table-title">' + queryInfosParceiroJSON.camposTabela[i].titulo + '</div>';

    if(i%4 == 0){
      montaLinhaTitulo += '</div>';
      montaTabela += montaLinhaTitulo;
      montaLinhaTitulo = '<div class="div-table-row">'
    }
    
    montaLinhaValor += '<div class="div-table-cell">' + queryInfosParceiroJSON.camposTabela[i].valor + '</div>';

    if(i%4 == 0){
      montaLinhaValor += '</div>';
      montaTabela += montaLinhaValor;
      montaLinhaValor = '<div class="div-table-row">'
    }

  }
  montaTabela += montaLinhaTitulo + '</div>' + montaLinhaValor;

  document.getElementById("tabelaJornada").innerHTML = montaTabela;
}