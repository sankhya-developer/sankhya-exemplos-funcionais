function openCard(idName) {
  var element = document.getElementById(idName);
  if(element.style.display == 'none' || element.style.display == '') {
    element.style.display = 'flex';
  } else {
    console.log(element);
    element.style.display = 'none';
  }
}