function abrirNivelIndicador(codParc, codEtapa, codIndicador){
 var params = {'A_CODPARC' : codParc, 'A_CODETAPA': codEtapa, 'A_CODINDICADOR': codIndicador};
 openLevel('lvl_k50kpc', params);
}

function montaCard(nomeArea, arrayIndicadoresArea, arrayIndicadoresPerc, arrayIndicadoresFarol, arrayIndicadoresCodParc, arrayIndicadoresCodEtapa, arrayIndicadoresCodIndicador) {
  var card = '<div class="card"><span class="title">' + nomeArea + '</span><div class="bar"> <div class="emptybar"></div><div class="filledbar" id="'+ nomeArea +'"></div><div class="indicador-container">';
  var farol = ''
  for (i = 0; i < arrayIndicadoresArea.length; i++) {
    if (arrayIndicadoresFarol[i] == 'Vermelho') {
      farol = '<div class="farol-vermelho"></div>';
    } else if (arrayIndicadoresFarol[i] == 'Amarelo') {
      farol = '<div class="farol-amarelo"></div>';
    } else if (arrayIndicadoresFarol[i] == 'Verde') {
      farol = '<div class="farol-verde"></div>';
    } else if (arrayIndicadoresFarol[i] == 'Azul') {
      farol = '<div class="farol-azul"></div>';
    } else if (arrayIndicadoresFarol[i] == ''){
      farol = '';
    }
    
    card += '<div class="conteudo-indicador" onClick="abrirNivelIndicador('+arrayIndicadoresCodParc[i]+','+arrayIndicadoresCodEtapa[i]+','+arrayIndicadoresCodIndicador[i]+')"><span class="nome-indicador">' + farol + arrayIndicadoresArea[i] + '</span><span class="perc-indicador">' + arrayIndicadoresPerc[i] + '</span></div>';
  }
  card += '</div></div></div>';
  return card;
}

function buscaContainerExibicao() {
  var containers = document.getElementsByClassName('card-container');
  for(i = 0; i < containers.length; i++) {
    if (containers[i].style.display == 'flex') {
      return containers[i].id;
    }
  }
  return null;
}

function montaCardContainer(queryInfosIndicadoresJSON, codEtapa) {
  var qtdCampos = queryInfosIndicadoresJSON.camposIndEtapa.length-1;
  var inicCardContainer = '';
  var finCardContainer = '';
  var arrayArea = [];
  var arrayIndicadoresArea = [];
  var arrayIndicadoresPerc = [];
  var arrayIndicadoresFarol = [];
  var arrayPercArea = [];
  var arrayIndicadoresCodIndicador = [];
  var arrayIndicadoresCodEtapa = [];
  var arrayIndicadoresCodParc = [];
  var conteudo = '';


  inicCardContainer = '<div id="' + codEtapa + '" class="card-container">';
  finCardContainer = '</div>';

  /* busca as áreas do card-container de cada etapa */
  for (j = 1; j <= qtdCampos; j++) {
    if (queryInfosIndicadoresJSON.camposIndEtapa[j].codEtapa == codEtapa) {
      if(!arrayArea.includes(queryInfosIndicadoresJSON.camposIndEtapa[j].area)){
        arrayArea.push(queryInfosIndicadoresJSON.camposIndEtapa[j].area);
        arrayPercArea.push(queryInfosIndicadoresJSON.camposIndEtapa[j].percArea);
      }
    }
  }

  /* busca indicadores de cada area */
  for (k = 0; k < arrayArea.length; k++) {
    for (l = 1; l <= qtdCampos; l++) {
      if (arrayArea[k] == queryInfosIndicadoresJSON.camposIndEtapa[l].area && queryInfosIndicadoresJSON.camposIndEtapa[l].codEtapa == codEtapa) {
        arrayIndicadoresArea.push(queryInfosIndicadoresJSON.camposIndEtapa[l].nomeIndicador);
        arrayIndicadoresPerc.push(queryInfosIndicadoresJSON.camposIndEtapa[l].realPerc);
        arrayIndicadoresFarol.push(queryInfosIndicadoresJSON.camposIndEtapa[l].faixa);
        arrayIndicadoresCodParc.push(queryInfosIndicadoresJSON.camposIndEtapa[l].codParc);
        arrayIndicadoresCodEtapa.push(queryInfosIndicadoresJSON.camposIndEtapa[l].codEtapa);
        arrayIndicadoresCodIndicador.push(queryInfosIndicadoresJSON.camposIndEtapa[l].codIndicador);
      }
    }
    conteudo += montaCard(
      arrayArea[k],
      arrayIndicadoresArea,
      arrayIndicadoresPerc,
      arrayIndicadoresFarol,
      arrayIndicadoresCodParc,
      arrayIndicadoresCodEtapa,
      arrayIndicadoresCodIndicador
    );

    arrayIndicadoresArea = [];
    arrayIndicadoresPerc = [];
    arrayIndicadoresFarol = [];
    arrayIndicadoresCodParc = [];
    arrayIndicadoresCodEtapa = [];
    arrayIndicadoresCodIndicador = [];
  }
  document.getElementById('cardEtapas').innerHTML = inicCardContainer + conteudo + finCardContainer;
  filledBar(arrayArea, arrayPercArea);
}

function filledBar(arrayArea, arrayPercArea) {
  for (i = 0; i < arrayArea.length; i++) {
    if(arrayPercArea[i] > 100){      
      arrayPercArea[i] = 100;
    } 
    document.getElementById(arrayArea[i]).style.width = arrayPercArea[i] + '%';
  }
}